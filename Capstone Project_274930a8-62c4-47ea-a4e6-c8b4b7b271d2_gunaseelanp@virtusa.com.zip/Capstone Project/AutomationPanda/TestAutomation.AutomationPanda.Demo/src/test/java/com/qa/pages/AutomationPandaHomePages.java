package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class AutomationPandaHomePages {
	WebDriver driver;

	@FindBy(xpath = "//a[text()='Contact']")
	WebElement ContactButton;
	public WebElement getContactButton() {
		return ContactButton;
	}

	public AutomationPandaHomePages(WebDriver rDriver) {
		this.driver = rDriver;
		PageFactory.initElements(new AjaxElementLocatorFactory(rDriver, 60), this);

	}
}
