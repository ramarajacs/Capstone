package com.qa.testscript;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_AutomationPanda_001 extends TestBase{
	@Test(priority = 0)
	public void checkTitle() throws IOException {
	  boolean homepagetitle=driver.getTitle().contains("Automation Panda");
	  if(homepagetitle) {
		  Assert.assertTrue(true);
	  }
	  else {
		  captureScreenshot(driver,"checkTitle");
		  Assert.assertTrue(false,"Title is not correct");
	  }
	}
	@Test(priority = 1)
	public void checkContactButton() throws IOException {
		boolean contactbutton=AutomationPandaHomePagesOR.getContactButton().isEnabled();
		if(contactbutton) {
			Assert.assertTrue(true);
		}
		else {
			captureScreenshot(driver, "checkContactButton");
			Assert.assertTrue(false,"contact button is not enabled");
		}
		AutomationPandaHomePagesOR.getContactButton().click();
		String contacttitle=driver.getTitle();
		Assert.assertEquals(contacttitle,"Contact | Automation Panda","contact page title is not correct");
	}

	@Test(priority = 2,dependsOnMethods = "checkContactButton")
	public void checkSubmit() throws IOException {
		AutomationPandaContactPagesOR.getName().sendKeys("Gunaseelan");
		AutomationPandaContactPagesOR.getEmail().sendKeys("xyz@gmail.com");
		AutomationPandaContactPagesOR.getMessage().sendKeys("automation panda ");
		if(AutomationPandaContactPagesOR.getSubmitButton().isEnabled()) {
            Assert.assertTrue(true);
		}
		else {
			captureScreenshot(driver,"checkSubmit");
			Assert.assertTrue(false,"submit button is not enabled");
		}
		AutomationPandaContactPagesOR.getSubmitButton().click();
		String message=AutomationPandaContactPagesOR.getSubmittedMessage().getText();
		if(message.contains("Your message has been sent")) {
			Assert.assertTrue(true);
		}
		else {
			captureScreenshot(driver, "checkSubmit");
			Assert.assertTrue(false,"message is not correct");
		}
	}

}
